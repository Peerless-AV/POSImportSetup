using System;

public partial class  Page_DZ000001 : PX.Web.UI.PXPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}
}
